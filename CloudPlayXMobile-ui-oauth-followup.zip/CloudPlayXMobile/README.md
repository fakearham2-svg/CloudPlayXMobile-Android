# CloudPlayX Mobile — v0.2 source

CloudPlayX Mobile is an Android, no-root prototype for browsing cloud files with block-based on-demand reads and a local cache. This source has been updated from the supplied v0.1 project with a redesigned native dashboard, an in-app cloud browser, improved Google authorization-token handling, and more useful API error messages.

## Current scope

- Google Drive API v3 (read-only; requires a correctly configured Android OAuth client)
- WebDAV (read-only)
- Built-in folder/file browser, with tap-to-open and long-press-to-save a local copy
- Android Storage Access Framework `DocumentsProvider` for compatible Android system file pickers
- 4 MiB block cache, cache budget, age cleanup, and cache clearing
- Streaming file copy to a user-selected SAF destination in 1 MiB chunks with progress reporting
- No root required; minimum Android version is API 26 (Android 8), so Android 12 is supported

Not included yet: a TeraBox provider, uploads/writes, archive extraction, a game installer/launcher, or a true system-wide mounted filesystem. The Windows app uses WinFsp, which cannot be used as-is on Android. Apps that require ordinary filesystem paths (including many game launchers) may not be able to use this provider directly. The new local-copy action lets you save a cloud file through Android's document picker, but it does not make every game compatible.

## Build in Android Studio

1. Install Android Studio with JDK 17 or newer.
2. Open the `CloudPlayXMobile` folder.
3. Let Android Studio sync/download the Gradle and Android Gradle Plugin dependencies.
4. Build with **Build > Make Project**, then run on an Android 12 device.

This source archive does not contain a complete Gradle wrapper script/JAR. Use Android Studio's Gradle integration or add a standard wrapper through Android Studio before using `gradlew` from a terminal. The repair environment also has no Android SDK, so the APK, Android lint, and real-device behavior could not be verified locally. GitHub Actions is configured to run unit tests, lint, build the APK from the checked-out source, verify the output, and upload the debug APK artifact; that workflow still needs a successful run to count as verified.

## Google Drive setup

1. In Google Cloud Console, create/select a project and enable **Google Drive API**.
2. Configure the OAuth consent screen. If the app is in Testing mode, add the Google account you will use as a test user.
3. Create an **Android OAuth client ID** using package name `app.cloudplayx.mobile` and the SHA-1 certificate of the key used to build/install the APK (debug and release keys have different SHA-1 values).
4. In Android Studio, open the Gradle tool window and run `app > Tasks > android > signingReport` to find the debug SHA-1. Add that exact SHA-1 in Google Cloud Console.
5. Install the app, tap **Connect Google Drive**, approve the requested read-only Drive permission, then tap **Test connection**. The dashboard only says Connected after a real list request succeeds.

The access token is kept in memory and is cleared when a Bearer-token request receives HTTP 401; it is not persisted to disk. If connection fails, the displayed HTTP error includes a short server response. Common causes:
- `401`: authorization expired or the requested scope was not granted; reconnect.
- `403` mentioning `accessNotConfigured`: enable Google Drive API in the selected Google Cloud project.
- `403` mentioning insufficient permissions: reconnect and approve the Drive read-only scope.
- OAuth client / developer error during sign-in: check the Android package name, SHA-1, consent-screen test user, and selected Cloud project.

The app uses the broad `drive.readonly` scope to browse all readable Drive files. This is not the same as `drive.file`, which is intentionally limited to files an app has been granted access to. The scope is read-only, but broad; consider `drive.file` only if the product requirements are narrowed to app-selected files.

## Where the drive appears

- **Inside CloudPlayX:** tap **Browse cloud files**. This is the reliable built-in browser and does not depend on your phone's file-manager brand.
- **Android system file picker:** tap **Check in Android file picker**. In the picker, open its navigation drawer / “Browse” locations and choose **CloudPlayX** if your Android build lists it.
- **Other file-manager apps:** many OEM file managers only show local storage and their own cloud integrations. Android `DocumentsProvider` roots are exposed through the Storage Access Framework, not mounted as a universal drive letter. A third-party file manager that does not use Android's document picker may never show CloudPlayX in its own navigation screen; this cannot be forced without changing how that file manager works.

## Cache behavior

Only requested blocks are downloaded and retained locally during virtual reads. The explicit long-press download action writes a separate copy to the location selected by the user. Cache cleanup deletes local cached blocks, not cloud originals. The cloud provider remains read-only; the app does not upload or write modifications back to the provider.

## Source map

- `MainActivity.kt` — redesigned dashboard, provider connection/testing, cache controls
- `BrowserActivity.kt` — built-in remote folder browser
- `CloudProvider.kt` — Android `DocumentsProvider` and virtual file reads via `openProxyFileDescriptor`
- `GoogleAuth.kt` — Google token handling
- `GoogleDriveRemote.kt`, `WebDavRemote.kt` — cloud backends
- `BlockCache.kt` — on-demand block download/cache
- `README-REPAIR-NOTES.md` — repair summary, verification limits, and remaining risks
- `Remote.kt` — shared provider interface
